package com.example;

import com.example.domain.*;

public class EmployeeTest {
	public static void main(String[] args)  {
		Employee emp1 = new Employee("Sean", "A123456789", 50000); 
		Admin emp2 = new Admin("Amy", "B210987654", 70000);
		Engineer emp3 = new Engineer("David", "C109876543", 80000);
		Manager emp4 = new Manager("Louis", "D124680135", 100000, "TW Sales");
		Director emp5 = new Director("Nicole", "R202468135", 120000, "Global Sales", 1000000);
		
		emp1.displayInformation();
		emp2.displayInformation();
		emp3.displayInformation();
		emp4.displayInformation();
		emp5.displayInformation();

	}
}
