package com.example.domain;

public class Engineer extends Employee {

	public Engineer(String name, String ssn, double salary) {
		super(name, ssn, salary);
	}

}
