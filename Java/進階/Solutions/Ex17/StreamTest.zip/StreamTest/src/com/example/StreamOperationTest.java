package com.example;

import java.util.*;
import java.util.stream.Collectors;

public class StreamOperationTest {

    public static void main(String[] args) {        
        List<Person> personList = Person.createList();
        
        // 顯示台北成員的性別稱謂, 以map()方法將性別轉換為先生或小姐
        System.out.println("顯示台北成員的性別稱謂");
        personList.stream().filter(p->p.getCity()==City.Taipei)
                .map(p -> p.getGender().getPrefix())
                .forEach(System.out::println);
        
        // 問候所有台南的成員(你好, Sean 先生), 以peek()方法在性別稱謂前列印問候語
        System.out.println("\n問候所有台南的成員");
        personList.stream().filter(p->p.getCity()==City.Tainan)
                .peek(p -> System.out.printf("您好,%s", p.getName()))
                .map(p -> p.getGender().getPrefix())
                .forEach(System.out::println);
        
        // 使用findFirst()方法取得第一個住台南的年齡小於35歲的女性,
        System.out.println("\n取得住台南的年齡小於35歲的女性");
        
        Optional<Person> result = personList.stream().filter(p->p.getCity()==City.Tainan)
                .filter(p->p.getGender()==Gender.FEMALE).findFirst();
        if(result.isPresent()){
            System.out.println(result.get());
        } else {
            System.out.println("無符合條件成員");
        }
        
        // 南部成員個數
        long southCount = personList.stream().filter(p->p.getCity()==City.Tainan||p.getCity()==City.Kaohsiung).count();
        System.out.println("\n南部成員個數:"+southCount);        
        
        //取得年紀最大的成員
        Person oldest = personList.stream().max(Person::compareAgeTo).get();
        System.out.println("\n年紀最大的成員:"+oldest.getName()+" "+oldest.getAge()+"歲");
        //取得年紀最小的成員
        Person youngest = personList.stream().min(Person::compareAgeTo).get();
        System.out.println("年紀最小的成員:"+youngest.getName()+" "+youngest.getAge()+"歲");
        //取得成員年紀總和
        int ageSum = personList.stream().mapToInt(p->p.getAge()).sum();
        System.out.println("成員年紀總和:"+ageSum+"歲");
        //取得成員年紀平均    
        double ageAvg = personList.stream().mapToInt(p->p.getAge()).average().getAsDouble();
        System.out.println("成員年紀平均:"+ageAvg+"歲");
        
        //女性成員排序
        System.out.println("\n女性成員排序");
        personList.stream().filter(p->p.getGender()==Gender.FEMALE).sorted()
                .forEach(p->System.out.printf("%s(%d)%s%n", p.getName(), p.getAge(), p.getCity()));
        //男性成員依城市排序        
        System.out.println("\n男性成員依城市排序");
        personList.stream().filter(p->p.getGender()==Gender.MALE).sorted((p1,p2)->p1.compareCityTo(p2))
                .forEach(p->System.out.printf("%s(%d)%s%n", p.getName(), p.getAge(), p.getCity()));
        //所有成員依年紀反向排序
        System.out.println("\n所有成員依年紀反向排序");
        personList.stream().sorted(Comparator.comparing(Person::getAge).reversed())
                .forEach(p->System.out.printf("%s(%d)%s%n", p.getName(), p.getAge(), p.getCity()));        
        //所有成員依城市->年紀兩階段排序
        System.out.println("\n所有成員依城市後年紀排序");
        personList.stream().sorted(Comparator.comparing(Person::getCity).thenComparing(Person::getAge))
                .forEach(p->System.out.printf("%s(%d)%s%n", p.getName(), p.getAge(), p.getCity()));
        
        //以收集器取得將女性成員排序後轉為新序列
        List<Person> newList = personList.stream().filter(p->p.getGender()==Gender.FEMALE).sorted().collect(Collectors.toList());
        System.out.println("\n女性成員排序之新序列:"+newList);
        //以收集器取得所有台北成員的電話序列        
        List<String> phoneList = personList.stream().filter(p->p.getCity()==City.Taipei).map(Person::getPhone).collect(Collectors.toList());
        System.out.println("\n台北成員電話序列:"+phoneList);
        //收集器產生計算台南成員平均年紀
        double avgAge = personList.stream().filter(p->p.getCity()==City.Tainan).collect(Collectors.averagingDouble(Person::getAge));
        System.out.println("\n台南成員平均年紀:"+avgAge);
        //收集器取得所有台北成員email字串用,隔開 
        String emailStr = personList.stream().filter(p->p.getGender()==Gender.FEMALE).map(Person::getEmail).collect(Collectors.joining(", "));
        System.out.println("\n女性成員email:"+emailStr);
        
        //成員依城市分組
        Map<City, List<Person>> cityMap = personList.stream().collect(Collectors.groupingBy(Person::getCity));
        System.out.println("\n成員依城市分組:");
        cityMap.forEach((k,v)->System.out.println(k+":"+v));
        
        //成員依城市計數
        Map<City, Long> cityCount = personList.stream().collect(Collectors.groupingBy(p->p.getCity(), Collectors.counting()));
        System.out.println("\n成員依城市計數:");
        cityCount.forEach((k,v)->System.out.println(k+":"+v+"人"));
        //成員依年齡分組
        Map<Boolean, List<Person>> ageMap = personList.stream().collect(Collectors.partitioningBy(p->p.getAge()>30));
        System.out.println("\n成員依年齡分組:");
        ageMap.forEach((k,v)->System.out.println((k?"大於":"小於")+"30歲:"+v));
    }           
}
