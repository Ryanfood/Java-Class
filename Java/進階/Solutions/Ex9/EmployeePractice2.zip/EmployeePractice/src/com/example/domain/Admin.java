package com.example.domain;

public class Admin extends Employee {

	public Admin(String name, String ssn, double salary) {
		super(name, ssn, salary);
	}

}
