package com.example;

import com.example.domain.*;

public class EmployeeTest {
	public static void main(String[] args)  {
		Employee[] emps = new Employee[5];
		emps[0] = new Employee("Sean", "A123456789", 50000);
		emps[1] = new Admin("Amy", "B210987654", 70000);
		emps[2] = new Engineer("David", "C109876543", 80000);
		emps[3] = new Manager("Louis", "D124680135", 100000, "TW Sales");
		emps[4]= new Director("Nicole", "R202468135", 120000, "Global Sales", 1000000);

		for(int i=0; i<emps.length; i++)
			emps[i].displayInformation();
		
		System.out.println("David 學會了Java, Android");
		if(emps[2] instanceof Engineer) {
			Engineer eng = (Engineer )emps[2];
			eng.addSkill("Java");
			eng.addSkill("Android");
		}
		
		System.out.println("部門分配.....");
		if(emps[3] instanceof Manager) {
			Manager m1 = (Manager)emps[3];
			m1.addEmployee(emps[0]);
			m1.addEmployee(emps[1]);
			m1.addEmployee(emps[2]);
		}
		
		((Manager)emps[4]).addEmployee(emps[3]);
		
		for(int i=0; i<emps.length; i++)
			emps[i].displayInformation();

	}
}
