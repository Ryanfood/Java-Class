package com.example.domain;

import java.util.ArrayList;

public class Manager extends Employee {
	private String deptName;
	private ArrayList employees;
	
	public Manager(String name, String ssn, double salary, String deptName) {
		super(name, ssn, salary);
		this.deptName = deptName;	
		employees = new ArrayList();
	}

	public String getDeptName() {
		return deptName;
	}

	public boolean addEmployee(Employee emp) {
		if(employees.contains(emp))
			return false;
		else {
			employees.add(emp);
			return true;
		}
	}
	
	public boolean removeEmployee(Employee emp) {
		if(employees.contains(emp)) {
			employees.remove(emp);
			return true;
		}
		return false;
	}
	
	public void printStaffDetails() {
		if(employees.size()>0) {
			System.out.print(getName()+"管理員工:");
			for(Object obj: employees) {
				if(obj instanceof Employee) {
					Employee e = (Employee)obj;
					System.out.print(String.format(" %s(%d)", e.getName(),e.getEmpId()));
				}
			}
			System.out.println();			
		}
	}
	
	
	
	@Override
	public void displayInformation() {
		super.displayInformation();
		System.out.println("管理部門: "+deptName);
		this.printStaffDetails();
	}
	
}
