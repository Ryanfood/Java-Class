package com.example;

public interface Pet {
	
	public void play();
	
}
