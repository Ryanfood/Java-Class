package com.example;

public interface StringAnalyzer {

	public boolean analyze(String target, String searchStr);
    

}
